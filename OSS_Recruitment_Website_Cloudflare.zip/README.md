# OSS Recruitment Website — Cloudflare Pages

A responsive black-and-gold OSS recruitment page with a server-side Cloudflare Pages Function that posts submissions to a Discord webhook. No database is required for this version.

## Files
- `index.html` — application website
- `oss-logo.png` — supplied OSS emblem
- `functions/api/apply.js` — server-side endpoint at `/api/apply`

## Deploy to Cloudflare Pages (free plan)

1. Create a GitHub repository and upload the contents of this folder.
2. In Cloudflare, open **Workers & Pages** → **Create** → **Pages** → connect to your repository.
3. For a plain HTML site, choose **None** as the framework preset, leave the build command blank, and set the build output directory to `/` if Cloudflare asks for it. If your deployment setup requires a build output folder, put these files in that folder and keep the `functions/` directory at its root.
4. In the Pages project, open **Settings → Variables and Secrets** (the exact label can vary) and add:
   - Name: `OSS_DISCORD_WEBHOOK`
   - Value: your Discord webhook URL
   Mark it as a secret if Cloudflare presents that option. Do not put the webhook in `index.html`, client-side JavaScript, GitHub, or screenshots.
5. Redeploy after adding the secret, then test with a sample application.

## Important security notes

- The webhook URL is only read by `functions/api/apply.js` on Cloudflare's server; visitors cannot read it from the website's page source.
- This starter includes required-field checks and a honeypot, but it does **not** include robust per-IP rate limiting, CAPTCHA, or duplicate-application prevention. Add a Cloudflare rate-limiting/WAF rule or Turnstile before sharing publicly.
- Anyone can still call the public `/api/apply` endpoint directly, so the webhook secret is hidden but the endpoint is not private.
- Webhook-only submissions are stored as Discord messages. A staff member with permission to access the channel may see them; deleted messages are not recoverable through this site.
- Avoid collecting sensitive information. This form only asks for community usernames, availability, experience, and written answers.
- This is a community recruitment portal and is not affiliated with a real government agency.

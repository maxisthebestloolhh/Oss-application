function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Cache-Control": "no-store",
      "X-Content-Type-Options": "nosniff"
    }
  });
}

function clean(value, max) {
  if (typeof value !== "string") return "";
  return value.trim().replace(/\u0000/g, "").slice(0, max);
}

export async function onRequestPost({ request, env }) {
  const contentType = request.headers.get("content-type") || "";
  if (!contentType.includes("application/json")) {
    return json({ error: "Invalid request format." }, 415);
  }

  const length = Number(request.headers.get("content-length") || "0");
  if (length > 12000) return json({ error: "Application is too large." }, 413);

  let raw;
  try { raw = await request.json(); }
  catch { return json({ error: "Invalid application data." }, 400); }

  // Honeypot field: silently reject simple automated spam.
  if (clean(raw.website, 200)) return json({ applicationId: "RECEIVED" });

  const app = {
    roblox: clean(raw.roblox, 32),
    discord: clean(raw.discord, 80),
    timezone: clean(raw.timezone, 80),
    motivation: clean(raw.motivation, 1800),
    experience: clean(raw.experience, 1200),
    scenario: clean(raw.scenario, 1800),
    conduct: clean(raw.conduct, 1400),
    availability: clean(raw.availability, 80),
    confirm: raw.confirm === true
  };

  if (!app.roblox || !app.discord || !app.timezone ||
      app.motivation.length < 30 || app.scenario.length < 30 ||
      app.conduct.length < 20 || !app.availability || !app.confirm) {
    return json({ error: "Please complete all required fields correctly." }, 400);
  }

  if (!env.OSS_DISCORD_WEBHOOK) {
    return json({ error: "Recruitment submissions are temporarily unavailable." }, 503);
  }

  // Create a reference without collecting additional personal data.
  const applicationId = "OSS-" + new Date().getUTCFullYear() + "-" +
    crypto.randomUUID().replace(/-/g, "").slice(0, 8).toUpperCase();

  const embed = {
    title: "NEW OSS APPLICATION",
    description: "A new recruitment application has been submitted through the OSS portal.",
    color: 0xF5C542,
    fields: [
      { name: "Application ID", value: applicationId, inline: true },
      { name: "Status", value: "PENDING REVIEW", inline: true },
      { name: "Roblox Username", value: app.roblox, inline: true },
      { name: "Discord Username", value: app.discord, inline: true },
      { name: "Usual Active Time / Timezone", value: app.timezone || "Not provided", inline: false },
      { name: "Motivation", value: app.motivation || "Not provided", inline: false },
      { name: "Relevant Experience", value: app.experience || "Not provided", inline: false },
      { name: "Situational Assessment — Conflicting Reports", value: app.scenario, inline: false },
      { name: "Situational Assessment — Information Handling", value: app.conduct, inline: false },
      { name: "Weekly Availability", value: app.availability, inline: true }
    ],
    footer: { text: "OSS Recruitment Portal • Community use only" },
    timestamp: new Date().toISOString()
  };

  let discordResponse;
  try {
    discordResponse = await fetch(env.OSS_DISCORD_WEBHOOK + "?wait=true", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: "OSS Recruitment",
        embeds: [embed],
        allowed_mentions: { parse: [] }
      })
    });
  } catch {
    return json({ error: "Could not deliver the application. Please try again later." }, 502);
  }

  if (!discordResponse.ok) {
    return json({ error: "Could not deliver the application. Please try again later." }, 502);
  }

  return json({ success: true, applicationId }, 200);
}
